Turn Word Wrap ON if you're using Notepad.

Virtual Panasonic JR-200U for Windows95/98, by James the Animal Tamer.

System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows95/98
DirectX
16-bit video card (Virtual Panasonic JR-200U will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX


Known Bugs
==========
1.  You must configure the printer filename before trying to LPRINT or LLIST or COPY.
2.  Nothing works very well.

Preliminary Note:
=================
Here's Panasonic JR-200U version 0.12.  The low number indicates that it's not working very well.

An important feature for BASIC programmers is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into the Virtual Panasonic JR.  This is much easier than trying to type in a program on the Virtual Panasonic JR itself (although that can be done).

Note that at present, Virtual Panasonic JR offers no way of saving your work, other than in a Quicktype TXT file as described above.


What works:
=====================
CPU (mostly)
Memory 
Keyboard (partly)
Video 
Quicktype (provides a means of loading in BASIC programs from text files)
Joystick (mostly working, but not configurable at present)
Video border
Window size configuration
BASIC LOAD (CJR files - Slow Fast mode only)
Sound (mostly)



What does NOT work:
=====================
BASIC LOAD (CJR files - Slow Slow mode, Fast Fast mode)
BASIC SAVE (CJR files)
Optional loading of other ROM OS
Insertion/removal of expansion cartridges
Timers 
Keyboard (scan mode)
Interrupts (I am missing one or two)
Accurate timing (needs work)
Other peripherals (hey, I've never even SEEN the disk drive!)



What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Pretty much everything


NOTES:
=====================
1.  Joysticks.  Virtual Panasonic JR uses DirectX for joystick input.  Virtual Panasonic JR is tuned for using "joypads."  The joypads I'm using are Microsoft Sidewinder Game Pads.

2.  Sound.  Uses DirectSound.  It is somewhat working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static.  Note that if your computer is not running the emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).  Also, the sound pitch is off.  There will be some sour notes.

3.  Keyboard.  Needs work.  The keyboard operates only in Sensible mode.  Single keystroke keyword entry is not supported yet.  Key beep, NMI disable, and a few other keyboard features are not implemented.

4.  LOAD.  To LOAD a .CJR file from BASIC, first type LOAD.  Press the Enter key when prompted to type RETURN.  Then select Play Cassette File from the File menu, and choose your .CJR cassette file.  .

5.  The Panasonic's BREAK key is mapped to the PC's ESC key.




Versions:
=========
March 25, 2002:  0.12
	Added presumed cassette interrupt.  Helps with Joe Junkman, but still not right.
	Scripting system now replaces appended cassette files.
	Sound works slightly better.
	Fixed the LIST/LLIST problem (bug in the CPU core).
	Replaced the CPU core, but it didn't fix LIST/LLIST.

June 17, 2001:  0.11
	BASIC LOAD works slightly better.  Sound works slightly better.
	

June 2, 2001: 0.1
	First sort-of working version



Credits
=======
Me (James the Animal Tamer) -- Everything that's not mentioned separately below

6802 emulator:		(6800.c) I grabbed this from MAME.  The author isn't mentioned.


Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98. 		 Thanks, Bill.

ROMs and .CJR files:	See those for their respective credits.


Random Jottings
===============
1.  What is a Panasonic JR-200U?
Quick Answer:  Panasonic's attempt to break into the USA home computer market in the early 1980s.  Sorry, I don't know much else.
	It features a microprocessor similar to Motorola's 6802.  It comes standard with 36K of RAM.  A score or so of games on cassette exist, including half a dozen from Disney.

==

2.  What is an emulator?
	An emulator is a software program which enables one computer to act like another.  It'll emulate the graphics, peripherals, sound, timing, etc.  Ideally, the emulator will run pretty much everything the emulated computer could run, and provide a similar "experience."

==

3.  Cool.  Now how do I get started?
	Double click the VPANAJR icon!
	From the file menu, select Play Game (script), and browse down to the Scripts directory.  Open Demo_Demo.TXT.
	Enjoy the show.

==

3.  How can I help?
	Well, maybe you're someone who originally developed for this system 'way back in 1982 or 1983.  If you have any documentation on this system, please let me know!

	If you have any stories about this computer, such as where you might have bought one 'way back when, I'd love to hear 'em.

	Also, if you have tapes for this system, digitize 'em and send 'em to me for inclusion at some future date in this archive.
	Try:  digitize both sides of the cassette to WAV files, twice.  Use settings of 44,100 Hz, 8-bit, stereo.  While recording from cassette to WAV, have all unneccessary electronic equipment nearby turned off -- a TV in the same room can make a mighty tape hum, despite your shielded cables!
	The reason for stereo is that on some tapes, there's good stuff on one track and noise on the other, or one track might be noisier than the other.  The Panasonic JR's tape format is to record in blocks and checksum each block, but still, better safe than sorry.


