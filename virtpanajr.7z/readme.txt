Turn Word Wrap ON if you're using Notepad.

See also the readme.txt in the docs directory.

This is the Quick Start document.

First, unzip all the files into a directory, e.g. c:\VPanaJR.

Cool.

Then double-click on the VPANAJR icon.

The emulator should now be running.

From the file menu, select Play Game (script), and browse down to the Scripts directory.  Open Demo_Demo.TXT.

==

After you've watched the demo, go and read the readme.txt that's in the DOCS directory!

You can't save your own BASIC files with this version.  Sorry!

You can play other game scripts too.


Enjoy!
James the Animal Tamer
2002
www.geocities.com/emucompboy

